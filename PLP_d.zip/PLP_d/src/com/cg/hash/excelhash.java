package com.cg.hash;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelhash {
	static Map<String, String> datamap = new HashMap<>();
	public static String[]  ece(String key) throws IOException
	{
		String arr[]=new String[5];
		File file = new File("D:\\Book5.xlsx");
	    FileInputStream fis = new FileInputStream(file);
	    XSSFWorkbook wb = new XSSFWorkbook(fis);
	    XSSFSheet sheet = wb.getSheetAt(0);
	    wb.close();
	    int lastRowNum = sheet.getLastRowNum() ;
	    int lastCellNum = sheet.getRow(0).getLastCellNum();
	    Object[][] obj = new Object[lastRowNum][1];
	    for (int i = 0; i < lastRowNum; i++) {
	     
	      for (int j = 0; j < lastCellNum; j++) {
	        
	    	  datamap.put(sheet.getRow(0).getCell(j).toString(), sheet.getRow(i+1).getCell(j).toString());
	      }
	      //obj[i][0] = datamap;
	       arr[i]=datamap.get(key);
	     
	    }
	   
	   return arr;
	}
	
	
	public static String[] quty(String key) throws IOException
	{
		String arr[]=new String[5];
		File file = new File("D:\\Book5.xlsx");
	    FileInputStream fis = new FileInputStream(file);
	    XSSFWorkbook wb = new XSSFWorkbook(fis);
	    XSSFSheet sheet = wb.getSheetAt(1);
	    wb.close();
	    int lastRowNum = sheet.getLastRowNum() ;
	    int lastCellNum = sheet.getRow(0).getLastCellNum();
	    Object[][] obj = new Object[lastRowNum][1];
	    for (int i = 0; i < lastRowNum; i++) {
	     
	      for (int j = 0; j < lastCellNum; j++) {
	        
	    	  datamap.put(sheet.getRow(0).getCell(0).toString(), sheet.getRow(i+1).getCell(0).toString());
	      }
	      //obj[i][0] = datamap;
	       arr[i]=datamap.get(key);
	     
	    }
	   
	   return arr;
	}
	
	
	
	
}
