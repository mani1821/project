package com.cg.testcase;

import static org.junit.Assert.*;

import java.io.IOException;

import jxl.JXLException;
import jxl.read.biff.BiffException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

import POM.*;
public class TCGroupD {

	Page pg=new Page();
	/*@BeforeMethod
	public void bfr() throws BiffException, InterruptedException, IOException
	{
		pg.ok();
		pg.login();
		pg.searchpro();
	}*/
	@Test(priority=1)
	public void test1() throws InterruptedException, JXLException, IOException
{
		pg.ok();
		pg.login();
		pg.searchpro();
	
		String str=pg.macbook.getText();
		System.out.println(str);
		assertEquals(str,"MacBook");
		
}
	
	@Test(priority=3)
	public void test2() throws InterruptedException, BiffException, IOException
	{
		pg.add();
		Thread.sleep(1000);
		try
		{
			assertEquals(pg.addmsg.toString(),"Success: You have added MacBook to your shopping cart!\n");
		}
		catch(Error e)
		{
			
		}
	}
	
	
	@Test(priority=2)
	public void test3() throws InterruptedException
	{
		pg.wish();
		Thread.sleep(1000);
		
		try
		{
			assertEquals(pg.wishmsg.toString(),"Success: You have added MacBook to your wish list!\n");
		}
		catch(Error e)
		{
			
		}
		
	}
	
	
	
	
	/*@AfterMethod
	public void aftr()
	{
		pg.close();
	}*/
}
