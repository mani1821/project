package POM;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.pagefactory.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import com.cg.hash.*;
import com.cg.excel.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Page {
	static WebDriver driver;

	
	
	@FindBy(xpath=".//*[@id='button-cart']")
	 public static WebElement acart;
	
	@FindBy(xpath=".//*[@id='content']/div/div[2]/div[1]/button[1]")
	public static WebElement wishlist;
	
	@FindBy(xpath="(//button[@type='button'])[9]")
	public static WebElement compare;
	
	@FindBy(xpath=".//*[@id='content']/div/div[1]/ul[2]/li[2]/a")
	public static WebElement Specification;
	
	@FindBy(xpath=".//*[@id='content']/div/div[1]/ul[2]/li[1]/a")
	public static WebElement Description;
	
	
	@FindBy(xpath=".//*[@id='content']/div/div[1]/ul[2]/li[3]/a")
	public static WebElement Reviews;
	
	
	@FindBy(xpath=".//*[@id='content']/div/div[1]/ul[1]/li[2]/a/img")
	public static WebElement imgshift1;
	
	
	@FindBy(xpath=".//*[@id='content']/div/div[1]/ul[1]/li[3]/a/img")
	public static WebElement imgshift2;
	
	
	@FindBy(id="input-quantity")
	public static WebElement Qty; 
	
	
	@FindBy(xpath=".//*[@id='top-links']/ul/li[2]/a")   
	public static WebElement myaccount;
	
	@FindBy(xpath=".//*[@id='top-links']/ul/li[2]/ul/li[2]/a")
	public static WebElement login;
	
	@FindBy(id="input-email")
	public static WebElement uid;
	
	@FindBy(id="input-password")
	public static WebElement pwd;
	

	@FindBy(xpath=".//*[@id='content']/div/div[2]/div/form/input")
	public static WebElement lgnbtn;
	
	
	@FindBy(xpath=".//*[@id='content']/div/div[2]/h1")
	public static WebElement macbook;
	@FindBy(xpath=".//*[@id='content']/div[3]/div[1]/div/div[1]/a/img")
	public static  WebElement mac;
	
	@FindBy(xpath=".//*[@id='search']/input")
public static WebElement search;	
	
	
	@FindBy(xpath=".//*[@id='search']/span/button")
	public static WebElement searchbtn;
	
	
	@FindBy(xpath=".//*[@id='product-product']/div[1]")
	public static WebElement addmsg;
	
	
	
	@FindBy(xpath=".//*[@id='product-product']/div[1]")
	public static WebElement wishmsg;
	
	
public static void uinput(String userid,String pswd)
{
	uid.sendKeys(userid);
	pwd.sendKeys(pswd);
}
	public void ok()
	{
	
		PageFactory.initElements(driver, Page.class);
		
	
	//driver.close();
		}
	public void login() throws InterruptedException, BiffException, IOException
	{
			driver=new FirefoxDriver();
			read r=new read();
			driver.get("https://demo.opencart.com");
			
			
			int totalNoOfRows =r.nofRows();
			// To get the number of columns present in sheet
			int totalNoOfCols =r.nofCols();
			PageFactory.initElements(driver, Page.class);
			//Thread.sleep(5000);
			myaccount.click();
			login.click();
			
			int row=1,col;
		for(row=1;row<totalNoOfRows;row++)
		{	uid.clear();
			pwd.clear();
		
	
		for(col=0;col<totalNoOfCols;col++)
		{
			if(col==0)
			{uid.sendKeys(r.readExcel(col,row));}
			if(col==1)
			{
				pwd.sendKeys(r.readExcel(col,row));
			}
			
		
		Thread.sleep(1000);
		}
		lgnbtn.click();
		}	
		//uid.sendKeys(uname);
		//pwd.sendKeys(pswd);
		//lgnbtn.click();
		
	}
	public void searchpro() throws InterruptedException
	{
		Thread.sleep(5000);
		search.sendKeys("MacBook");	
		searchbtn.click();
		mac.click();
	}
	public void close()
	{
		driver.close();
	}
	public void add() throws InterruptedException, BiffException, IOException
	{
		read r=new read();
		Qty.clear();
		String arr[]=excelhash.quty("Quantity");
		Qty.sendKeys(arr[1]);
		acart.click();
		
	}
	public void wish()
	{
		wishlist.click();
	}
	}
	
	
	
	
	
	

